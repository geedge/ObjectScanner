#!/bin/bash
source /root/.bash_profile
killall object_scanner_dmn.sh object_scanner
./object_scanner_dmn.sh &>/dev/null &
